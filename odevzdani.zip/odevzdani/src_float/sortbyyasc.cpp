#include "sortbyyasc.h"

SortByYAsc::SortByYAsc()
{

}
