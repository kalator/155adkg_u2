/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "draw.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QHBoxLayout *horizontalLayout;
    Draw *canvas;
    QVBoxLayout *verticalLayout;
    QPushButton *helpButton;
    QFrame *line_8;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *pointCount;
    QLabel *label_4;
    QComboBox *shapeBox;
    QPushButton *generateButton;
    QSpacerItem *verticalSpacer_3;
    QFrame *line_2;
    QLabel *label;
    QLabel *label_5;
    QComboBox *methodCombo;
    QPushButton *createCHButton;
    QLabel *timer;
    QFrame *line_3;
    QLabel *label_6;
    QLabel *label_7;
    QCheckBox *checkBox;
    QPushButton *createRectButton;
    QSpacerItem *verticalSpacer_5;
    QFrame *line_6;
    QFrame *line_5;
    QPushButton *clearButton;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(798, 554);
        Widget->setMinimumSize(QSize(782, 535));
        horizontalLayout = new QHBoxLayout(Widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        canvas = new Draw(Widget);
        canvas->setObjectName(QString::fromUtf8("canvas"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(canvas->sizePolicy().hasHeightForWidth());
        canvas->setSizePolicy(sizePolicy);
        canvas->setMinimumSize(QSize(641, 511));
        canvas->setCursor(QCursor(Qt::CrossCursor));

        horizontalLayout->addWidget(canvas);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        helpButton = new QPushButton(Widget);
        helpButton->setObjectName(QString::fromUtf8("helpButton"));
        helpButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(helpButton);

        line_8 = new QFrame(Widget);
        line_8->setObjectName(QString::fromUtf8("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_8);

        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(Widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        pointCount = new QLineEdit(Widget);
        pointCount->setObjectName(QString::fromUtf8("pointCount"));

        verticalLayout->addWidget(pointCount);

        label_4 = new QLabel(Widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        shapeBox = new QComboBox(Widget);
        shapeBox->setObjectName(QString::fromUtf8("shapeBox"));
        shapeBox->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(shapeBox);

        generateButton = new QPushButton(Widget);
        generateButton->setObjectName(QString::fromUtf8("generateButton"));
        generateButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(generateButton);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        line_2 = new QFrame(Widget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);

        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font);

        verticalLayout->addWidget(label);

        label_5 = new QLabel(Widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        methodCombo = new QComboBox(Widget);
        methodCombo->setObjectName(QString::fromUtf8("methodCombo"));
        methodCombo->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(methodCombo);

        createCHButton = new QPushButton(Widget);
        createCHButton->setObjectName(QString::fromUtf8("createCHButton"));
        createCHButton->setMinimumSize(QSize(99, 23));
        createCHButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(createCHButton);

        timer = new QLabel(Widget);
        timer->setObjectName(QString::fromUtf8("timer"));

        verticalLayout->addWidget(timer);

        line_3 = new QFrame(Widget);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        label_6 = new QLabel(Widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(Widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font);

        verticalLayout->addWidget(label_7);

        checkBox = new QCheckBox(Widget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setCursor(QCursor(Qt::PointingHandCursor));
        checkBox->setChecked(true);

        verticalLayout->addWidget(checkBox);

        createRectButton = new QPushButton(Widget);
        createRectButton->setObjectName(QString::fromUtf8("createRectButton"));
        createRectButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(createRectButton);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_5);

        line_6 = new QFrame(Widget);
        line_6->setObjectName(QString::fromUtf8("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_6);

        line_5 = new QFrame(Widget);
        line_5->setObjectName(QString::fromUtf8("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_5);

        clearButton = new QPushButton(Widget);
        clearButton->setObjectName(QString::fromUtf8("clearButton"));
        clearButton->setMinimumSize(QSize(99, 23));
        clearButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(clearButton);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Convex Hull Creator 0.1", 0, QApplication::UnicodeUTF8));
        helpButton->setText(QApplication::translate("Widget", "Help!", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_2->setToolTip(QApplication::translate("Widget", "<html><head/><body><p>Generate selected number of points lying on chosen geometrical shape.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_2->setText(QApplication::translate("Widget", "Point generator", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Widget", "How many points:", 0, QApplication::UnicodeUTF8));
        pointCount->setText(QApplication::translate("Widget", "100", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("Widget", "That lie on:", 0, QApplication::UnicodeUTF8));
        shapeBox->clear();
        shapeBox->insertItems(0, QStringList()
         << QApplication::translate("Widget", "Random", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Grid", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Circle", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Ellipse", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Square", 0, QApplication::UnicodeUTF8)
        );
        generateButton->setText(QApplication::translate("Widget", "Generate!", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label->setToolTip(QApplication::translate("Widget", "<html><head/><body><p>Compute and create convex hull using one of the methods.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label->setText(QApplication::translate("Widget", "Create convex hull", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("Widget", "Using method:", 0, QApplication::UnicodeUTF8));
        methodCombo->clear();
        methodCombo->insertItems(0, QStringList()
         << QApplication::translate("Widget", "Jarvis Scan", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Graham Scan", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Quick Hull", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "Sweep Line", 0, QApplication::UnicodeUTF8)
        );
        createCHButton->setText(QApplication::translate("Widget", "Go!", 0, QApplication::UnicodeUTF8));
        timer->setText(QString());
#ifndef QT_NO_TOOLTIP
        label_6->setToolTip(QApplication::translate("Widget", "<html><head/><body><p>Create minimal bounding rectangle. To compute main direction line, leave the &quot;Draw dir. line&quot; checkbox ticked.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_6->setText(QApplication::translate("Widget", "Create minimal", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        label_7->setToolTip(QApplication::translate("Widget", "<html><head/><body><p>Create minimal bounding rectangle. To compute main direction line, leave the &quot;Draw dir. line&quot; checkbox ticked.</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        label_7->setText(QApplication::translate("Widget", "bounding rectangle", 0, QApplication::UnicodeUTF8));
        checkBox->setText(QApplication::translate("Widget", "Draw dir. line", 0, QApplication::UnicodeUTF8));
        createRectButton->setText(QApplication::translate("Widget", "Go!", 0, QApplication::UnicodeUTF8));
        clearButton->setText(QApplication::translate("Widget", "Clear!", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
