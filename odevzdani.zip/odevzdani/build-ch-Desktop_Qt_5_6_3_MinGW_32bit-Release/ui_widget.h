/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "draw.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QHBoxLayout *horizontalLayout;
    Draw *canvas;
    QVBoxLayout *verticalLayout;
    QPushButton *helpButton;
    QFrame *line_8;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *pointCount;
    QLabel *label_4;
    QComboBox *shapeBox;
    QPushButton *generateButton;
    QSpacerItem *verticalSpacer_3;
    QFrame *line_2;
    QLabel *label;
    QLabel *label_5;
    QComboBox *methodCombo;
    QPushButton *createCHButton;
    QLabel *timer;
    QFrame *line_3;
    QSpacerItem *verticalSpacer_5;
    QFrame *line_6;
    QFrame *line_5;
    QPushButton *clearButton;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(798, 554);
        Widget->setMinimumSize(QSize(782, 535));
        horizontalLayout = new QHBoxLayout(Widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        canvas = new Draw(Widget);
        canvas->setObjectName(QStringLiteral("canvas"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(canvas->sizePolicy().hasHeightForWidth());
        canvas->setSizePolicy(sizePolicy);
        canvas->setMinimumSize(QSize(641, 511));
        canvas->setCursor(QCursor(Qt::CrossCursor));

        horizontalLayout->addWidget(canvas);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        helpButton = new QPushButton(Widget);
        helpButton->setObjectName(QStringLiteral("helpButton"));
        helpButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(helpButton);

        line_8 = new QFrame(Widget);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_8);

        label_2 = new QLabel(Widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(Widget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        pointCount = new QLineEdit(Widget);
        pointCount->setObjectName(QStringLiteral("pointCount"));

        verticalLayout->addWidget(pointCount);

        label_4 = new QLabel(Widget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout->addWidget(label_4);

        shapeBox = new QComboBox(Widget);
        shapeBox->setObjectName(QStringLiteral("shapeBox"));
        shapeBox->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(shapeBox);

        generateButton = new QPushButton(Widget);
        generateButton->setObjectName(QStringLiteral("generateButton"));
        generateButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(generateButton);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        line_2 = new QFrame(Widget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);

        label = new QLabel(Widget);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);

        verticalLayout->addWidget(label);

        label_5 = new QLabel(Widget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout->addWidget(label_5);

        methodCombo = new QComboBox(Widget);
        methodCombo->setObjectName(QStringLiteral("methodCombo"));
        methodCombo->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(methodCombo);

        createCHButton = new QPushButton(Widget);
        createCHButton->setObjectName(QStringLiteral("createCHButton"));
        createCHButton->setMinimumSize(QSize(99, 23));
        createCHButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(createCHButton);

        timer = new QLabel(Widget);
        timer->setObjectName(QStringLiteral("timer"));

        verticalLayout->addWidget(timer);

        line_3 = new QFrame(Widget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_5);

        line_6 = new QFrame(Widget);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_6);

        line_5 = new QFrame(Widget);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_5);

        clearButton = new QPushButton(Widget);
        clearButton->setObjectName(QStringLiteral("clearButton"));
        clearButton->setMinimumSize(QSize(99, 23));
        clearButton->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(clearButton);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Convex Hull Creator 0.1", Q_NULLPTR));
        helpButton->setText(QApplication::translate("Widget", "Help!", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        label_2->setToolTip(QApplication::translate("Widget", "<html><head/><body><p>Generate selected number of points lying on chosen geometrical shape.</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        label_2->setText(QApplication::translate("Widget", "Point generator", Q_NULLPTR));
        label_3->setText(QApplication::translate("Widget", "How many points:", Q_NULLPTR));
        pointCount->setText(QApplication::translate("Widget", "100", Q_NULLPTR));
        label_4->setText(QApplication::translate("Widget", "That lie on:", Q_NULLPTR));
        shapeBox->clear();
        shapeBox->insertItems(0, QStringList()
         << QApplication::translate("Widget", "Random", Q_NULLPTR)
         << QApplication::translate("Widget", "Grid", Q_NULLPTR)
         << QApplication::translate("Widget", "Circle", Q_NULLPTR)
         << QApplication::translate("Widget", "Ellipse", Q_NULLPTR)
         << QApplication::translate("Widget", "Square", Q_NULLPTR)
        );
        generateButton->setText(QApplication::translate("Widget", "Generate!", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        label->setToolTip(QApplication::translate("Widget", "<html><head/><body><p>Compute and create convex hull using one of the methods.</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        label->setText(QApplication::translate("Widget", "Create convex hull", Q_NULLPTR));
        label_5->setText(QApplication::translate("Widget", "Using method:", Q_NULLPTR));
        methodCombo->clear();
        methodCombo->insertItems(0, QStringList()
         << QApplication::translate("Widget", "Jarvis Scan", Q_NULLPTR)
         << QApplication::translate("Widget", "Graham Scan", Q_NULLPTR)
         << QApplication::translate("Widget", "Quick Hull", Q_NULLPTR)
         << QApplication::translate("Widget", "Sweep Line", Q_NULLPTR)
        );
        createCHButton->setText(QApplication::translate("Widget", "Go!", Q_NULLPTR));
        timer->setText(QString());
        clearButton->setText(QApplication::translate("Widget", "Clear!", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
